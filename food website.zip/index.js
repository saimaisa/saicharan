
let cart = document.getElementById("cart")
let option = documnet.getElementById("option")

option.onclick=function(){
    let div = document.createElement("div")
    option.appendchild(div)
    let h2 = document.createElement("h2")
    h2.textContent="shiva"
    div.appendchild(h2)
}

